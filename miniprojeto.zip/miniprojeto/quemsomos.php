<br>
<h2 style="font-weight: bold; font-family:verdana; color: B769B1; font-size: 36px">SOBRE NÓS</h2>
<br>
<div>
    <p style="font-family:verdana">
    Somos uma das principais consultorias especializadas em DADOS e INTELIGÊNCIA ARTIFICIAL do Brasil, com foco na TRANSFORMAÇÃO CULTURAL e ANALÍTICA de médias e grandes organizações
    </p>
    <br>
    <p style="font-family:verdana">
    Somos aceleradores da cultura Data Driven nas organizações. Nosso foco é implantar Inteligência Estratégica e potencializar a cultura dos dados para os nossos clientes! Possuímos conhecimento nas mais variadas tecnologias, o que nos permite moldar soluções abrangentes e flexíveis.
    </p>
    <br>
    <p style="font-family:verdana">
    Somos ágeis, analíticos e avançados e temos uma cultura leve, horizontal e muito colaborativa! Nosso propósito é empoderar as pessoas por meio dos dados.
    </p>
    <img src="img/foto1.jpg" width="600" height="400">
</div>
<br>
<div>
    <h2 style="font-weight: bold; font-family:verdana; color: B769B1; font-size: 36px">NOSSOS VALORES</h2>
    <br>
    <p style="font-family:verdana">
        Vivemos uma relação de transparência, confiança e proximidade com nossos clientes.
    </p>
    <br>
    <p style="font-family:verdana">
        Acreditamos que uma gestão aberta contribui para o crescimento dos nossos colaboradores.
    </p>
    <br>
    <p style="font-family:verdana">
        Trabalhamos não apenas para vender um produto, mas para proporcionar autonomia e sucesso aos nossos clientes.
    </p>

</div>