<nav class="navbar-center" class="navbar navbar-light" style="background-color: #ffffff;">
  <div class="container">
    <div class="navbar-header">
      <ul class="nav nav-justified" class="navbar navbar-light" style="background-color: #ffffff;">
        <li><a href="?pg=principal" style="font-weight: bold; font-family:verdana; color: 33ABCE; font-size: 26px">Home</a></li>
    		<li><a href="?pg=quemsomos" style="font-weight: bold; font-family:verdana; color: 33ABCE; font-size: 26px">Quem Somos</a></li>
    		<li><a href="?pg=servicos" style="font-weight: bold; font-family:verdana; color: 33ABCE; font-size: 26px">Serviços</a></li>
    		<li><a href="?pg=faleconosco" style="font-weight: bold; font-family:verdana; color: 33ABCE; font-size: 26px">Fale conosco</a></li>
      </ul>
    </div>
  </div>
</nav>
