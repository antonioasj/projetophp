<br>
<div class="container">
	<h2 style="font-family:verdana; color: 33ABCE; font-size: 40px">Dúvidas? <br> Informações? <br> Sugestões? <br> Propostas?</h2> 
	<form style="font-weight: bold; font-family:verdana; color: 33ABCE; id="contactForm" action="?pg=contatodb" method="post">

	<br>
     
	Nome <input type="text" class="form-control" name="nome" required="" data-validation-required-message="Please enter your name." >
	Email <input type="email" class="form-control" name="email"/>
	Telefone <input type="tel" class="form-control" name="telefone"/>
	Assunto <input type="text" class="form-control" name="assunto"/>
	Mensagem <textarea class="form-control" name="mensagem" rows="5" cols="10"></textarea><br>
	<button type="submit" class="btn btn-primary">Enviar</button>
	</form>
</div>