<?php
	include("config.inc.php");
?>
<header class=page-header>
	<center>
		<h1 style="background-color: #ffffff">
			<img src="img/deepdata.png" width="300" height="200">
		</h1>
	</center>
</header>