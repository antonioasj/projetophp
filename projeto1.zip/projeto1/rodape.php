<footer>
    <hr>
    <center><?= date("Y"); ?> &copy; DeepData - Desenvolvido por Antônio Augusto. Todos os direitos reservados. </center>
</footer>
