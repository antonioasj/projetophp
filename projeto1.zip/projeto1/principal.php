<div class="row">
    <br>
    <h2 class="page-header" style="font-weight: bold; font-family:verdana; color: B769B1; font-size: 36px">Use inteligência <br> artificial para resolver <br> problemas complexos</h2>
    <h4 style="font-family:verdana; color: 9E9E9E; font-size: 20px" > Organizamos seus <br> dados e geramos valor <br> para sua empresa. </h4>

    <br>
    <br>
    <br>

    <div class="col-md-12" style="background-color:#33ABCE">
      <div class="panel" style="background-color:#33ABCE">
        <div class="panel-heading" style="background-color:#33ABCE">
          <h3 style="font-family:verdana; color: FFFFFF; font-size: 20px">Desenvolva uma gestão de alto impacto para o seu negócio. Somos especialistas em criar significado
para os seus dados. Utilizamos, integramos e criamos diversas tecnologias em Inteligência Artificial.</h3> 
        </div>
        <div style="background-color:#33ABCE" class="col-md-6 col-serv">
          <h4 style="font-weight: bold; font-family:verdana; color: FFFFFF; font-size: 20px">ANÁLISES AVANÇADAS DE DADOS</h4>
            <p style="font-family:verdana; color: FFFFFF; font-size: 15px">Entenda padrões e relações entre indicadores com uma visão 360º do negócio. Gere valor com dados de imagens, áudios e textos (NLP e Deep Learning).</p>
        </div>
        <div style="background-color:#33ABCE" class="col-md-6 col-proj">
          <h4 style="font-weight: bold; font-family:verdana; color: FFFFFF; font-size: 20px">SELF SERVICE ANALYTICS</h4>
            <p style="font-family:verdana; color: FFFFFF; font-size: 15px">Implante modelos de machine learning capazes de prever o que vai acontecer com antecedência e planeje ações de forma proativa.</p>
        </div>
      </div>    
    </div>
  </div>